IMAGE_TAG=2.7.5
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=linux/amd64 #,linux/arm64
