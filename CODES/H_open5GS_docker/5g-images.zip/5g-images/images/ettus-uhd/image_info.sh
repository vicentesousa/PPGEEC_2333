IMAGE_TAG=4.1.0
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=linux/amd64,linux/arm64
