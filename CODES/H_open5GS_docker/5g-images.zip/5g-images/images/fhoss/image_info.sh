IMAGE_TAG=develop
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=linux/amd64