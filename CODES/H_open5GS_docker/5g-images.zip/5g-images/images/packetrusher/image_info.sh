IMAGE_TAG=2b26573
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=
