IMAGE_TAG=5.3-dev
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=linux/amd64