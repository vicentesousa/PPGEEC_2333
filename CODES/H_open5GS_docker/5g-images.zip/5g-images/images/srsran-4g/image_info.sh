IMAGE_TAG=23_11
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=
