IMAGE_TAG=2025.w19
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=
