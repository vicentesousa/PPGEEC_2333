IMAGE_TAG=1.1.1
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=linux/amd64,linux/arm64
