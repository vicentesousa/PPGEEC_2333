IMAGE_TAG=24_10_1
#comma separated list of platforms. If empty, image will not be multiarch.
PLATFORMS=
